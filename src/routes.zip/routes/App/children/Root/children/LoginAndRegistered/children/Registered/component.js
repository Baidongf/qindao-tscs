import React from 'react'
import './component.scss'


class Registered extends React.Component {


  render() {
    return (
      <div className="login-container">
        1234
      </div>
    )
  }
}

export default Registered
