import Component from 'components/RelateSchedule'
export default Component
