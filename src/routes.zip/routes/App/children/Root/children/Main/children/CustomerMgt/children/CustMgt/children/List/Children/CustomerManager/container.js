import { connect } from 'react-redux'
import Component from './component'
// import {} from 'store/modules/customerMgt/customerMgt'

const mapStateToProps = (state) => ({

})

const mapDispatchToProps = {}

export default connect(mapStateToProps, mapDispatchToProps)(Component)
