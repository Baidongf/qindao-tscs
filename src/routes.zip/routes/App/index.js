import Component from './container'
export default Component
